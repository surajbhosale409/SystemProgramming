Assignment for Encoding Contents of a file, and then again Decode that to get original contents.

[1] Encoding code is written in encode.py,
    contents of file will be encoded in following schema:
        'a' will be replaced 'c'
        i.e. character will be replaced by 2nd next character
    encode.py will take data.txt as input file and create a encodeddata file named encodeddata.txt
    For executing type below command :
          python encode.py

[2] Decoding code is written in decode.py,
    contents of encodeddata file will be decoded in following schema:
        'c' will be replaced 'a'
        i.e. character will be replaced by 2nd previous character
    decode.py will take encodeddata.txt as input file and create a decodeddata file named decodeddata.txt
    For executing type below command :
          python decode.py


