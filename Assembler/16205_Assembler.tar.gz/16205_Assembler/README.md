SURAJ RAJENDRA BHOSALE
16205

Hello sir,
       I have provided my source code for assembler in file 'firstPass.py'. In that I have gnerated Symbol Table,
       Literal table, Error table and intermediate code for given input file 'p.asm' (Assembly code).

      Files provided:
          [1] firstPass.py - Code for first pass of my assembler
          [2] p.asm        - Assembly Code for parsing
          [3] makefile     - makefile for executing code
          [4] README.md    - README.md file for information and instrunctions
          [5] reg.py       - registers table information library file
          [6] op.py        - instrunctions and opcodes table information library file
      

      [1] To execute: make myasm
      [2] After Executing:
            Symbol table is stored in file 'symTab.tbl'
            Literal table is stored in file 'litTab.tbl'
            Intermediate code is stored in file 'p.i'

Thanks and Regards.
