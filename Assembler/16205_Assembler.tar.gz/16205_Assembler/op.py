opcodes={ "add":"OP1", "cld":"OP2" , "cmp":"OP3" , "dec":"OP4" , "div":"OP5","inc":"OP6","int":"OP7","jmp":"OP8","lodsb":"OP9","lodsd":"OP10","mov":"OP11","movsb":"OP12","movsd":"OP13","mul":"OP14","pop":"OP15","popa":"OP16","push":"OP17","pusha":"OP18","ret":"OP19","scasb":"op20","std":"OP21","stosb":"OP22","stosd":"OP23","sub":"OP24","xor":"OP25","jz":"OP26","je":"OP27","jg":"OP28","jl":"OP29"}


