Hello,
	I have provied 2 shell scripts to fetch valid emails,domains from given data files

	[1] ./grep_emails     -> run this for fetching valid emails data from file 'gmail_data' and store thati
	 valid data in 'validMailData' file.

	[2] ./grep_domains    -> to fetch valid domains from same input file and store into 'validDomainsData' file
